
import { Tournament } from '../types';

const INITIAL_TOURNAMENTS: Tournament[] = [
  { 
    id: 't1', 
    title: 'Diamond Elite Battle', 
    prizePool: '$5,000', 
    entryFee: '$50', 
    participants: 128, 
    maxParticipants: 256, 
    status: 'UPCOMING', 
    type: 'Pro',
    startTime: Date.now() + 15 * 60000,
    isFull: false
  },
  { 
    id: 't4', 
    title: 'Free Sunday Special', 
    prizePool: '$200', 
    entryFee: 'FREE', 
    participants: 1020, 
    maxParticipants: 1024, 
    status: 'UPCOMING', 
    type: 'Classic',
    startTime: Date.now() + 120 * 60000,
    isFull: false
  }
];

class TournamentService {
  private tournaments: Tournament[] = [];
  private listeners: ((tournaments: Tournament[]) => void)[] = [];

  constructor() {
    const saved = localStorage.getItem('ludo_tournaments');
    this.tournaments = saved ? JSON.parse(saved) : INITIAL_TOURNAMENTS;
    
    // Simulate other players joining every 15 seconds
    setInterval(() => {
      this.tournaments = this.tournaments.map(t => {
        if (t.participants < t.maxParticipants && Math.random() > 0.7) {
          return { ...t, participants: t.participants + 1, isFull: (t.participants + 1) >= t.maxParticipants };
        }
        return t;
      });
      this.notify();
    }, 15000);
  }

  getTournaments() {
    return this.tournaments;
  }

  addTournament(tournament: Tournament) {
    this.tournaments.unshift(tournament);
    this.notify();
  }

  joinTournament(id: string) {
    this.tournaments = this.tournaments.map(t => {
      if (t.id === id && t.participants < t.maxParticipants) {
        const updated = { ...t, participants: t.participants + 1 };
        updated.isFull = updated.participants >= updated.maxParticipants;
        return updated;
      }
      return t;
    });
    this.notify();
  }

  subscribe(callback: (tournaments: Tournament[]) => void) {
    this.listeners.push(callback);
    callback(this.tournaments);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify() {
    localStorage.setItem('ludo_tournaments', JSON.stringify(this.tournaments));
    this.listeners.forEach(l => l(this.tournaments));
  }
}

export const tournamentService = new TournamentService();
