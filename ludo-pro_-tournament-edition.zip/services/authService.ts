
import { UserProfile } from '../types';

const AUTH_KEY = 'ludo_pro_session';

class AuthService {
  private currentUser: UserProfile | null = null;
  private listeners: ((user: UserProfile | null) => void)[] = [];

  constructor() {
    const saved = localStorage.getItem(AUTH_KEY);
    if (saved) {
      this.currentUser = JSON.parse(saved);
    }
  }

  getUser() {
    return this.currentUser;
  }

  isAuthenticated() {
    return this.currentUser !== null;
  }

  login(email: string, pass: string): Promise<UserProfile> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const user: UserProfile = {
          id: 'LUDO-' + Math.floor(Math.random() * 10000),
          username: email.split('@')[0],
          email: email,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
          level: 1,
          rank: 'Bronze',
          country: 'United Kingdom',
          countryCode: 'GB',
          status: 'Online',
          balance: 100.00, // Starting bonus
          bonusBalance: 50.00,
          winBalance: 0,
          gullaBalance: 0,
          fairPlayScore: 100,
          banStatus: false,
          stats: { played: 0, wins: 0, losses: 0, winRate: 0, tournamentWins: 0, bestStreak: 0 }
        };
        this.currentUser = user;
        localStorage.setItem(AUTH_KEY, JSON.stringify(user));
        this.notify();
        resolve(user);
      }, 1000);
    });
  }

  register(username: string, email: string): Promise<UserProfile> {
    // Similar to login for mock purposes
    return this.login(email, 'password');
  }

  logout() {
    this.currentUser = null;
    localStorage.removeItem(AUTH_KEY);
    this.notify();
  }

  subscribe(callback: (user: UserProfile | null) => void) {
    this.listeners.push(callback);
    callback(this.currentUser);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.currentUser));
  }
}

export const authService = new AuthService();
